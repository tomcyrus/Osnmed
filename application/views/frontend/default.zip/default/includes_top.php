<link rel="favicon" href="<?php echo base_url() . 'assets/frontend/default/img/icons/favicon.ico' ?>">
<link rel="apple-touch-icon" href="<?php echo base_url() . 'assets/frontend/default/img/icons/icon.png'; ?>">

<?php if ($page_name == "home") : ?>
    <link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/default/css/jquery.webui-popover.min.css'; ?>">
    <link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/default/css/slick.css'; ?>">
    <link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/default/css/slick-theme.css'; ?>">
<?php endif; ?>

<!-- font awesome 5 -->
<link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/default/css/fontawesome-all.min.css'; ?>">

<link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/default/css/bootstrap.min.css'; ?>">

<link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/default/css/main.css'; ?>">
<link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/default/css/responsive.css'; ?>">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700" rel="stylesheet">

<link rel="stylesheet" href="<?php echo base_url() . 'assets/global/toastr/toastr.css' ?>">





  <!-- <link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/assets/css/all.css'; ?>">

  <link rel="stylesheet" href=" <?php echo base_url() . 'assets/frontend/assets/css/bootstrap.min.css'; ?>">
 
  <link rel="stylesheet" href=" <?php echo base_url() . 'assets/frontend/assets/css/swiper-bundle.css'; ?>">
 
  <link rel="stylesheet" href="  <?php echo base_url() . 'assets/frontend/assets/css/swiper-bundle.min.css'; ?>">

  <link rel="stylesheet" href="  <?php echo base_url() . 'assets/frontend/assets/css/style.css'; ?>">

  <link rel="stylesheet" href="  <?php echo base_url() . 'assets/frontend/assets/css/responsive.css'; ?>"> -->



  <link rel="stylesheet" href=" <?php echo base_url() . 'assets/frontend/theme/plugins/bootstrap/bootstrap.min.css'; ?>">
 
  <!-- slick slider -->
  <link rel="stylesheet" href="  <?php echo base_url() . 'assets/frontend/theme/plugins/slick/slick.css'; ?>">

  <!-- themefy-icon -->
  <link rel="stylesheet" href="  <?php echo base_url() . 'assets/frontend/theme/plugins/themify-icons/themify-icons.css'; ?>">

  <!-- animation css -->
  <link rel="stylesheet" href=" <?php echo base_url() . 'assets/frontend/theme/plugins/animate/animate.css'; ?>">
 
  <!-- aos -->
  <link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/theme/plugins/aos/aos.css'; ?>">
  
  <!-- venobox popup -->
  <link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/theme/plugins/venobox/venobox.css'; ?>">
  

  <!-- Main Stylesheet -->
  <link href="<?php echo base_url() . 'assets/frontend/theme/css/style.css'; ?>" rel="stylesheet">
  

  <!--Favicon-->
  <link rel="shortcut icon" href="<?php echo base_url() . 'assets/frontend/images/favicon.png'; ?>" type="image/x-icon">
  
  <link rel="icon" href="  <?php echo base_url() . 'assets/frontend/images/favicon.png'; ?>" type="image/x-icon">



<!-- <script src="<?php echo base_url('assets/backend/js/jquery-3.3.1.min.js'); ?>"></script> -->
